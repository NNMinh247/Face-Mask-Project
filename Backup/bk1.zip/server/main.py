import uvicorn
import cv2
import numpy as np
import mediapipe as mp
import sqlite3
import pickle
import os
from datetime import datetime
from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from keras_facenet import FaceNet
from typing import List

# --- 1. CẤU HÌNH & KHỞI TẠO ---

# Biến toàn cục để lưu Cache trên RAM (Tăng tốc độ nhận diện)
GLOBAL_CACHE = {
    "vectors": None, # Ma trận numpy chứa toàn bộ vector (N x 512)
    "names": []      # Danh sách tên tương ứng với từng hàng của ma trận
}

DB_PATH = "database/users.db"

# Khởi tạo AI
print("⏳ Đang tải mô hình AI (FaceNet + MediaPipe)...")
embedder = FaceNet()
mp_face_detection = mp.solutions.face_detection
face_detection = mp_face_detection.FaceDetection(min_detection_confidence=0.5)
print("✅ AI đã sẵn sàng!")

# --- 2. QUẢN LÝ DATABASE & CACHE ---

def init_db():
    """Tạo bảng Database nếu chưa có"""
    if not os.path.exists("database"):
        os.makedirs("database")
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users 
                 (name TEXT PRIMARY KEY, vectors BLOB)''')
    conn.commit()
    conn.close()

def reload_cache():
    """
    Load toàn bộ dữ liệu từ DB lên RAM.
    Chuyển đổi thành Ma trận NumPy để tính toán siêu tốc.
    """
    print("🔄 Đang làm mới Cache dữ liệu...")
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT name, vectors FROM users")
    rows = c.fetchall()
    conn.close()

    all_vectors = []
    all_names = []

    for name, blob in rows:
        vectors_list = pickle.loads(blob) # List các vector của 1 người
        for vec in vectors_list:
            all_vectors.append(vec)
            all_names.append(name) # Tên lặp lại theo số lượng vector mẫu

    if len(all_vectors) > 0:
        # Chuyển list thành Ma trận (Matrix) NumPy
        GLOBAL_CACHE["vectors"] = np.array(all_vectors) 
        GLOBAL_CACHE["names"] = all_names
        print(f"✅ Đã load {len(all_names)} vector khuôn mặt vào RAM.")
    else:
        GLOBAL_CACHE["vectors"] = None
        GLOBAL_CACHE["names"] = []
        print("⚠️ Database trống.")

def save_user_to_db(name, vectors):
    """Lưu người dùng mới vào DB và cập nhật Cache ngay lập tức"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    vectors_blob = pickle.dumps(vectors)
    
    try:
        # Dùng INSERT OR REPLACE để cập nhật nếu tên đã tồn tại
        c.execute("INSERT OR REPLACE INTO users (name, vectors) VALUES (?, ?)", (name, vectors_blob))
        conn.commit()
    finally:
        conn.close()
    
    # Cập nhật nóng Cache (Hot Reload)
    reload_cache()

# --- 3. LIFESPAN (Chạy khi Server Khởi động/Tắt) ---
@asynccontextmanager
async def lifespan(app: FastAPI):
    # 1. Khi server bật
    init_db()
    reload_cache()
    yield
    # 2. Khi server tắt (Clean up nếu cần)
    print("🛑 Server đang tắt...")

app = FastAPI(lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- 4. HÀM XỬ LÝ ẢNH (CORE) ---
def process_image_to_vector(image_bytes):
    """Chuyển ảnh raw -> vector 512 chiều"""
    nparr = np.frombuffer(image_bytes, np.uint8)
    image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    if image is None: return None

    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    results = face_detection.process(image_rgb)
    
    if not results.detections: return None

    # Lấy khuôn mặt to nhất (độ tin cậy cao nhất)
    detection = results.detections[0]
    bboxC = detection.location_data.relative_bounding_box
    h, w, _ = image.shape
    
    x = int(bboxC.xmin * w)
    y = int(bboxC.ymin * h)
    width = int(bboxC.width * w)
    height = int(bboxC.height * h)
    
    # Margin an toàn để không cắt mất cằm/trán
    x, y = max(0, x), max(0, y)
    
    face_crop = image_rgb[y:y+height, x:x+width]
    if face_crop.size == 0: return None
    
    # FaceNet yêu cầu input 160x160
    face_crop = cv2.resize(face_crop, (160, 160))
    
    # Lấy embedding (vector đặc trưng)
    embeddings = embedder.embeddings(np.expand_dims(face_crop, axis=0))
    return embeddings[0]

# --- 5. API ENDPOINTS ---

@app.get("/")
def home():
    return {
        "status": "System Running", 
        "total_vectors": len(GLOBAL_CACHE["names"]),
        "users": list(set(GLOBAL_CACHE["names"])) # Lấy danh sách tên duy nhất
    }

@app.delete("/reset-database/")
def reset_database():
    """Xóa sạch dữ liệu để làm lại từ đầu"""
    try:
        if os.path.exists(DB_PATH):
            os.remove(DB_PATH)
        init_db()
        reload_cache()
        return {"message": "Đã xóa toàn bộ dữ liệu hệ thống!"}
    except Exception as e:
        raise HTTPException(500, f"Lỗi khi xóa: {e}")

@app.post("/register/")
async def register(name: str = Form(...), files: List[UploadFile] = File(...)):
    new_vectors = []
    
    # 1. Xử lý ảnh đầu vào
    for file in files:
        content = await file.read()
        vec = process_image_to_vector(content)
        if vec is not None:
            new_vectors.append(vec)
    
    if len(new_vectors) == 0:
        raise HTTPException(400, "Không tìm thấy khuôn mặt rõ ràng trong các ảnh gửi lên!")

    # 2. Kiểm tra trùng lặp (Dùng Ma trận tính toán cho nhanh)
    if GLOBAL_CACHE["vectors"] is not None:
        # Tính khoảng cách từ vector mẫu đầu tiên tới TOÀN BỘ DB
        # input_vec (512,) - matrix (N, 512) -> broadcasting
        distances = np.linalg.norm(GLOBAL_CACHE["vectors"] - new_vectors[0], axis=1)
        min_dist = np.min(distances)
        
        # Ngưỡng 0.6 cho check trùng (khắt khe hơn nhận diện)
        if min_dist < 0.60:
            idx = np.argmin(distances)
            existing_name = GLOBAL_CACHE["names"][idx]
            # Nếu trùng tên chính mình thì cho phép update (ghi đè)
            if existing_name != name:
                raise HTTPException(409, f"Khuôn mặt này đã tồn tại dưới tên: {existing_name}")

    # 3. Lưu vào DB & Update Cache
    save_user_to_db(name, new_vectors)
    
    return {"message": f"Đăng ký thành công: {name} ({len(new_vectors)} mẫu khuôn mặt)"}

@app.post("/recognize/")
async def recognize(file: UploadFile = File(...)):
    """
    Hàm nhận diện tối ưu hóa dùng Vectorization.
    Độ phức tạp giảm từ O(N*M) xuống O(1) nhờ NumPy C-backend.
    """
    # 1. Xử lý ảnh
    content = await file.read()
    input_vec = process_image_to_vector(content)
    if input_vec is None: 
        raise HTTPException(400, "Không tìm thấy khuôn mặt")

    # 2. Kiểm tra Cache
    if GLOBAL_CACHE["vectors"] is None:
        return {"user": "Unknown", "match": False, "detail": "Chưa có dữ liệu huấn luyện"}

    # --- TỐI ƯU HÓA THUẬT TOÁN Ở ĐÂY ---
    
    # Bước A: Trừ vector input cho toàn bộ ma trận DB (Broadcasting)
    # Kết quả: Ma trận hiệu (N, 512)
    diff = GLOBAL_CACHE["vectors"] - input_vec
    
    # Bước B: Tính độ dài (Norm L2) của từng dòng
    # Kết quả: Mảng khoảng cách (N,)
    distances = np.linalg.norm(diff, axis=1)
    
    # Bước C: Tìm khoảng cách nhỏ nhất
    min_index = np.argmin(distances)
    min_dist = distances[min_index]
    
    identity = GLOBAL_CACHE["names"][min_index]
    
    # Bước D: Kiểm tra ngưỡng (Threshold)
    # Ngưỡng 0.75: Cân bằng giữa nhận nhầm và không nhận ra
    threshold = 0.75 
    
    now = datetime.now().strftime("%H:%M:%S - %d/%m/%Y")

    if min_dist < threshold:
        confidence = round((1 - min_dist) * 100, 2)
        return {
            "user": identity, 
            "confidence": confidence, 
            "match": True,
            "time": now
        }
    
    return {"user": "Unknown", "match": False, "confidence": round((1 - min_dist) * 100, 2)}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
import axios from 'axios';

const API_URL = 'http://localhost:8000';

export const registerUser = async (name, imageBlobs) => {
    const formData = new FormData();
    formData.append('name', name);
    
    const imagesToCheck = Array.isArray(imageBlobs) ? imageBlobs : [imageBlobs];
    
    imagesToCheck.forEach((blob, index) => {
        if (blob) {
            formData.append('files', blob, `face_${index}.jpg`);
        }
    });

    const res = await axios.post(`${API_URL}/register/`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
    });
    return res.data;
};

export const recognizeUser = async (imageBlob) => {
    const formData = new FormData();
    const blobToSend = Array.isArray(imageBlob) ? imageBlob[0] : imageBlob;
    formData.append('file', blobToSend, 'check.jpg');
    
    const res = await axios.post(`${API_URL}/recognize/`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
    });
    return res.data;
};

export const checkMaskQuick = async (blob) => {
    try {
        const formData = new FormData();
        formData.append('file', blob, 'check.jpg');
        const res = await axios.post(`${API_URL}/check-mask/`, formData, { timeout: 2000 });
        return res.data.mask; 
    } catch (error) {
        return false; 
    }
};
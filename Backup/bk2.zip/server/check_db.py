import sqlite3
import pickle
import numpy as np
import os

# Cấu hình numpy để in số cho đẹp (không in dạng khoa học 1e-5)
np.set_printoptions(suppress=True, precision=4, linewidth=100)

DB_PATH = "database/users.db"

def inspect_database():
    if not os.path.exists(DB_PATH):
        print(f"❌ Lỗi: Không tìm thấy file '{DB_PATH}'")
        print("👉 Bạn cần chạy file main.py ít nhất 1 lần để tạo DB.")
        return

    print(f"\n{'='*60}")
    print(f"🕵️  KIỂM TRA DỮ LIỆU BÊN TRONG FILE: {DB_PATH}")
    print(f"{'='*60}\n")

    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        # Lấy dữ liệu
        cursor.execute("SELECT name, vectors FROM users")
        rows = cursor.fetchall()

        if len(rows) == 0:
            print("⚠️  Database đang trống (Chưa có ai đăng ký).")
        else:
            for i, row in enumerate(rows):
                name = row[0]       # Tên người dùng
                blob_data = row[1]  # Cục dữ liệu thô (Blob)
                
                # Giải mã Blob thành List các Vector
                vectors_list = pickle.loads(blob_data)
                
                print(f"👤 USER {i+1}: {name.upper()}")
                print(f"💾 Số lượng khuôn mặt đã học: {len(vectors_list)}")
                print("-" * 50)

                for j, vec in enumerate(vectors_list):
                    print(f"   ➤ Vector mẫu số {j+1} (512 chiều):")
                    
                    # CÁCH 1: In rút gọn (Dễ nhìn cấu trúc)
                    # In 5 số đầu ... 5 số cuối
                    print(f"     [{vec[0]:.4f}, {vec[1]:.4f}, {vec[2]:.4f}, {vec[3]:.4f}, {vec[4]:.4f} ... {vec[-1]:.4f}]")
                    
                    # CÁCH 2: Muốn xem FULL 512 số thì bỏ comment dòng dưới đây:
                    # print(vec) 
                    
                    print("") # Xuống dòng cho thoáng
                
                print("="*60)

    except sqlite3.OperationalError:
        print("❌ Lỗi: Bảng 'users' chưa được tạo.")
    except Exception as e:
        print(f"❌ Lỗi không xác định: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    inspect_database()

### Cách chạy kiểm tra:

# 1.  Mở Terminal tại thư mục `server`.
# 2.  Chạy lệnh:
#     ```powershell
#     python check_db.py